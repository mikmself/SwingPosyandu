package posyandu;
import Form.Master.Login;
public class Posyandu {
    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
    }
    
}
